package com.gt.sample;

import javax.net.ssl.*;
import java.io.*;
import java.net.URL;
import java.security.KeyStore;

public class MTLSClient {

	public static void main(String[] args) throws Exception {
		// Load the client certificate and private key
		KeyStore clientKeyStore = KeyStore.getInstance("JKS");
		char[] password = "123321".toCharArray();
		clientKeyStore.load(new FileInputStream("C:\\Users\\alpayka\\Desktop\\9396e0f3-ba8f-42d6-bfde-072a3294ed15.jks"), password);

		// Load the server's public certificate
		KeyStore trustStore = KeyStore.getInstance("JKS");
		trustStore.load(new FileInputStream("C:\\Users\\alpayka\\Desktop\\truststore.jks"), "123123".toCharArray());

		// Create an SSL context with mutual authentication
		SSLContext sslContext = SSLContext.getInstance("TLS");
		KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
		kmf.init(clientKeyStore, password);
		TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
		tmf.init(trustStore);
		sslContext.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

		// Set the custom SSL context
		HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());

		// Create the URL object for the service
		URL url = new URL("https://mcustomers.garantibbva.com.tr/");

		// Open a connection to the service
		HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();

		// Set the request method
		connection.setRequestMethod("GET");

		// Send the request and receive the response
		int responseCode = connection.getResponseCode();
		System.out.println("Response Code: " + responseCode);

		// Read the response
		BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		String line;
		StringBuilder response = new StringBuilder();
		while ((line = reader.readLine()) != null) {
			response.append(line);
		}
		reader.close();

		// Print the response
		System.out.println("Response: " + response.toString());

		// Close the connection
		connection.disconnect();
	}
}