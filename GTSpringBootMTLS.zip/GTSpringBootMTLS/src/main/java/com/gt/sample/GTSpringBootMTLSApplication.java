package com.gt.sample;

import java.io.File;
import java.nio.charset.Charset;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GTSpringBootMTLSApplication {
	public static String directory = "C:\\Users\\AlpayKa\\Desktop\\c\\";

//	-Dcom.sun.security.enableCRLDP=true
//	-Dcom.sun.net.ssl.checkRevocation=true
//	
//	static {
//		System.setProperty("com.sun.security.enableCRLDP", "true");
//		System.setProperty("com.sun.net.ssl.checkRevocation", "true");
//		System.setProperty("com.sun.security.ssl.crlURL", "http://localhost:8081/revoked.crl");
//		System.setProperty("javax.net.ssl.trustStore", "C:\\Users\\AlpayKa\\Desktop\\keystores\\truststore.jks");
//		System.setProperty("javax.net.ssl.trustStorePassword", "123123");
//		
//		System.setProperty("javax.net.ssl.trustStore.crl", "C:\\Users\\AlpayKa\\Desktop\\keystores\\truststore.jks");
//		System.setProperty("javax.net.ssl.trustStore.crlPassword", "123123");
////		System.setProperty("com.sun.net.ssl.ocsp.responderURL", "http://127.0.0.1:9006");
////		System.setProperty("com.sun.net.ssl.checkRevocation", "true");
//////		System.setProperty("com.sun.security.crl.cacheSize", "0");
//////		System.setProperty("com.sun.security.crl.cacheTimeout", "5");
////		System.setProperty("javax.net.ssl.trustStoreType", "PKCS12");
////		
//////		System.setProperty("com.sun.security.enableCRLDP", "true");
////		System.setProperty("com.sun.security.crl.file", "C:\\Users\\AlpayKa\\Desktop\\keystores\\revoked.crl");
//		System.setProperty("javax.net.debug", "all");
////		
//////		-Dcom.sun.security.enableCRLDP=true
//////				-Dcom.sun.net.ssl.checkRevocation=true
//////				-Dcom.sun.security.crl.file=<path-to-crl-file>
//	}

	public static void main(String[] args) {
		if (args != null && args.length > 0) {
			directory = args[0].endsWith(File.separator) ? args[0] : args[0] + File.separator;
			System.out.println("Path has been picked up: " + directory);
		}
		SpringApplication.run(GTSpringBootMTLSApplication.class, args);
	}
}
