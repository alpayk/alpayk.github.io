package com.gt.sample;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Base64;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;

import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import sun.security.provider.X509Factory;

@RestController
public class TestController {

	private HttpServletRequest request;

	public TestController(HttpServletRequest request) {
		this.request = request;
	}

	@GetMapping("/")
	public String index() {
		X509Certificate[] certs = (X509Certificate[]) request.getAttribute("javax.servlet.request.X509Certificate");

		if (certs != null && certs.length > 0) {
			return certs[0].getSubjectDN().getName();
		} else {
			return "no certs provided";
		}
	}

	public int getRandomInt() {
		Random rand = new Random();
		return rand.nextInt((100 - 1) + 1) + 1;
	}

	public String getRandomStr() {
		int leftLimit = 97; // letter 'a'
		int rightLimit = 122; // letter 'z'
		int targetStringLength = 8;
		Random random = new Random();

		String generatedString = random.ints(leftLimit, rightLimit + 1).limit(targetStringLength)
				.collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append).toString();

		return generatedString;
	}

	@GetMapping("/rand")
	public Map<String, Object> randJson() {
		Map<String, Object> map = new HashMap<>();
		map.put("strKey1", getRandomStr());
		map.put("strKey2", getRandomStr());
		map.put("intKey1", getRandomInt());
		map.put("intKey2", getRandomInt());
		return map;
	}

	public static X509Certificate parseCertificate(String certStr) {
		try {
			byte[] decoded = Base64.getDecoder()
					.decode(certStr.replaceAll(X509Factory.BEGIN_CERT, "").replaceAll(X509Factory.END_CERT, ""));

			return (X509Certificate) CertificateFactory.getInstance("X.509")
					.generateCertificate(new ByteArrayInputStream(decoded));
		} catch (Exception e) {
			return null;
		}
	}

	@GetMapping("/crt")
	public Map<String, Object> getParsedCert() {
		Map<String, Object> map = new HashMap<>();

		String certStr = request.getHeader("x-client-cert");

		X509Certificate cert = parseCertificate(certStr);

		map.put("subject", cert.getSubjectDN().getName());
		map.put("serial", cert.getSerialNumber());

		return map;
	}

	@GetMapping("/hdr")
	public Map<String, Object> getHeaders() {
		Map<String, Object> map = new HashMap<>();
		for (Enumeration<?> e = request.getHeaderNames(); e.hasMoreElements();) {
			String nextHeaderName = (String) e.nextElement();
			String headerValue = request.getHeader(nextHeaderName);
			map.put(nextHeaderName, headerValue);
		}

		return map;
	}

	@GetMapping("/file/{fileName:.+}")
	public ResponseEntity<Resource> downloadFile(@PathVariable String fileName) {
		if (GTSpringBootMTLSApplication.directory == null) {
			return new ResponseEntity<>(HttpStatus.SERVICE_UNAVAILABLE);
		}
		File file = new File(GTSpringBootMTLSApplication.directory + fileName);
		if (file.exists() && file.isFile()) {
			Resource resource = new FileSystemResource(file);
			HttpHeaders headers = new HttpHeaders();
			headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + file.getName());
			headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_OCTET_STREAM_VALUE);
			return new ResponseEntity<>(resource, headers, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
}