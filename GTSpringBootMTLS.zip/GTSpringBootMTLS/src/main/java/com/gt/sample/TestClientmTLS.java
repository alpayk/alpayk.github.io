package com.gt.sample;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.URL;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.Principal;
import java.security.PrivateKey;
import java.security.UnrecoverableEntryException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509KeyManager;

public class TestClientmTLS {

	private static final String TRUSTSTORE_PASS = "123123";
	private static final String TRUSTSTORE_PATH = "truststore.jks";
	private static final String KEYSTORE_PASS = "123321";
	private static final String KEYSTORE_PATH = "9396e0f3-ba8f-42d6-bfde-072a3294ed15.jks";
	private static final int DEFAULT_BUFFER_SIZE = 4096;

	private static final String MTLS_TEST_URL = "https://mcustomers.garantibbva.com.tr/gbadsm/advanced-sign-mgmt-public/security-server-mtls/v1/mtlstesting";
	private static final String ALIAS = "f2594835-700b-4cfa-a4e3-cc995ae0f719";

	private static String convertInputStreamToString(InputStream is) throws IOException {

		ByteArrayOutputStream result = new ByteArrayOutputStream();
		byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
		int length;
		while ((length = is.read(buffer)) != -1) {
			result.write(buffer, 0, length);
		}

		return result.toString("UTF-8");
	}

	public static void main(String[] args) {
		try {
			KeyStore keyStore = KeyStore.getInstance("JKS");
			FileInputStream fileInputStream = new FileInputStream(KEYSTORE_PATH);
			String password = KEYSTORE_PASS;
			keyStore.load(fileInputStream, password.toCharArray());

			KeyStore.PrivateKeyEntry privateKeyEntry = (KeyStore.PrivateKeyEntry) keyStore.getEntry(ALIAS,
					new KeyStore.PasswordProtection(password.toCharArray()));
			PrivateKey privateKey = privateKeyEntry.getPrivateKey();

			KeyStore trustStore = KeyStore.getInstance("JKS");
			trustStore.load(new FileInputStream(TRUSTSTORE_PATH), TRUSTSTORE_PASS.toCharArray());

			TrustManagerFactory trustManagerFactory = TrustManagerFactory
					.getInstance(TrustManagerFactory.getDefaultAlgorithm());
			trustManagerFactory.init(trustStore);

			TrustManager[] trustManagers = trustManagerFactory.getTrustManagers();

			SSLContext sslContext = SSLContext.getInstance("TLS");
			sslContext.init(
					new KeyManager[] {
							new KeyManagerImpl(privateKey, (X509Certificate) privateKeyEntry.getCertificate()) },
					trustManagers, null);

			SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

			URL url = new URL(MTLS_TEST_URL);

			/*
			 * 
			 * HttpsURLConnection[] conns = new HttpsURLConnection[500];
			 * 
			 * for (int i = 0; i < 500; i++) { conns[i] = (HttpsURLConnection)
			 * url.openConnection(); conns[i].setSSLSocketFactory(sslSocketFactory);
			 * conns[i].setRequestMethod("POST");
			 * 
			 * System.out.println("#" + i + " -> " + conns[i].getResponseCode()); }
			 * 
			 */

			HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();

			connection.setSSLSocketFactory(sslSocketFactory);
			connection.setRequestMethod("POST");

			int responseCode = connection.getResponseCode();
			System.out.println("HTTPCode: " + responseCode);
			if (responseCode == HttpsURLConnection.HTTP_OK) {
				InputStream responseStream = connection.getInputStream();
				System.out.println(convertInputStreamToString(responseStream));
				responseStream.close();
			} else {
				InputStream errorStream = connection.getErrorStream();
				System.err.println(convertInputStreamToString(errorStream));
				errorStream.close();
			}

			connection.disconnect();

		} catch (IOException | KeyStoreException | NoSuchAlgorithmException | CertificateException
				| UnrecoverableEntryException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static class KeyManagerImpl implements X509KeyManager {
		private final PrivateKey privateKey;
		private final X509Certificate certificate;

		public KeyManagerImpl(PrivateKey privateKey, X509Certificate certificate) {
			this.privateKey = privateKey;
			this.certificate = certificate;
		}

		@Override
		public String chooseClientAlias(String[] keyType, Principal[] issuers, Socket socket) {
			return "";
		}

		@Override
		public X509Certificate[] getCertificateChain(String alias) {
			return new X509Certificate[] { certificate };
		}

		@Override
		public PrivateKey getPrivateKey(String alias) {
			return privateKey;
		}

		@Override
		public String chooseServerAlias(String keyType, Principal[] issuers, Socket socket) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public String[] getServerAliases(String keyType, Principal[] issuers) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public String[] getClientAliases(String keyType, Principal[] issuers) {
			// TODO Auto-generated method stub
			return null;
		}

	}
}